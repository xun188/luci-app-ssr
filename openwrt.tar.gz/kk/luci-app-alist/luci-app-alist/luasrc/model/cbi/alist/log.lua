m = Map("alist")

m:append(Template("alist/alist_log"))

return m
