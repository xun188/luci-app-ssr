tccutil reset Camera cn.better365.ishot
tccutil reset Microphone cn.better365.ishot
tccutil reset ScreenCapture cn.better365.ishot