tccutil reset All com.surteesstudios.Bartender
tccutil reset Camera com.surteesstudios.Bartender
tccutil reset Microphone com.surteesstudios.Bartender
tccutil reset ScreenCapture com.surteesstudios.Bartender