tccutil reset All com.wiheads.paste
tccutil reset Camera com.wiheads.paste
tccutil reset Microphone com.wiheads.paste
tccutil reset ScreenCapture com.wiheads.paste