tccutil reset Camera com.techsmith.camtasia2023
tccutil reset Microphone com.techsmith.camtasia2023
tccutil reset ScreenCapture com.techsmith.camtasia2023
tccutil reset All com.techsmith.camtasia2023
codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLExporter
codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLThumbnailer