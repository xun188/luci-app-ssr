package utils

import (
	log "github.com/sirupsen/logrus"
)

var Log = log.New()
