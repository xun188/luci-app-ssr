package errs

import "fmt"

var (
	SearchNotAvailable = fmt.Errorf("search not available")
)
